create database stock;
use stock;

create table stock(id int auto_increment primary key,name varchar(22),price double,quantity int,amount double,brokerage double);
select * from stock;
