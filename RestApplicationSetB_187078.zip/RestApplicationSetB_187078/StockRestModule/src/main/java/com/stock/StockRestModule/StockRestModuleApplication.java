package com.stock.StockRestModule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockRestModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockRestModuleApplication.class, args);
	}

}
