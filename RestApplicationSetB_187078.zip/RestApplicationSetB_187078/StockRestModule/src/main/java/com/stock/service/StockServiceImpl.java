package com.stock.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.stock.entity.Stock;
import com.stock.exception.NoSuchStockException;
import com.stock.exception.StockNotFoundException;
import com.stock.repository.StockRepo;




@Service
public class StockServiceImpl {
	@Autowired
	StockRepo stockRepository;
	double price;
	int quantity;
	double amount;
	
	@Transactional
	//createing  new stock 
	public String createStock(Stock stock) {
		Stock stocks =  new Stock();
		stocks.setName(stock.getName());
		stocks.setPrice(stock.getPrice());
		stocks.setQuantity(stock.getQuantity());
		stocks.setAmount(stock.getAmount());
		stocks.setBrokerage(stock.getBrokerage());
		stockRepository.saveAndFlush(stock);
		return "Stock with stock id "+stock.getId() + " stock created successfully";
    }
	
	//finding stock with id
	public Stock findsingleStocks(int id) throws NoSuchStockException{
		Optional<Stock> opt=stockRepository.findById(id);
		if(opt.isPresent()) {
			Stock entity=opt.get();
			Stock stocks = new Stock();
			stocks.setId(entity.getId());
			stocks.setName(entity.getName());
			stocks.setPrice(entity.getPrice());
			stocks.setQuantity(entity.getQuantity());
			stocks.setAmount(entity.getAmount());
			stocks.setBrokerage(entity.getBrokerage());
			return stocks;
		}
		else {
			throw new NoSuchStockException("Stock with " + id + " does not exist");
		}
		
	}
	
	//fetching stock 
	public List<Stock> viewallStock() throws StockNotFoundException{
		List<Stock> entityList= stockRepository.findAll();
		if(entityList.isEmpty() || entityList.size()==0) {
			throw new StockNotFoundException("stock details does not exist");
		}
		List<Stock>list = new ArrayList();
		for (Stock entity : entityList) {
			Stock stocks = new Stock();
			stocks.setName(entity.getName());
			stocks.setPrice(entity.getPrice());
			stocks.setQuantity(entity.getQuantity());
			stocks.setAmount(entity.getAmount());
			stocks.setBrokerage(entity.getBrokerage());
			list.add(stocks);
		}
		return list;
		
	}
	
	//updating stock
	public String updateStock(int id,Stock stock) throws NoSuchStockException{
		Optional<Stock> opt=stockRepository.findById(id);
		if(opt.isPresent())
		 {
			Stock stocks=opt.get();
			stocks.setName(stock.getName());
			stocks.setPrice(stock.getPrice());
			stocks.setQuantity(stock.getQuantity());
			stocks.setAmount(stock.getAmount());
			stocks.setBrokerage(stock.getBrokerage());
			
		 } 
		else {
			throw new NoSuchStockException("Stock with " + id + " does not exist");
		}
		return "Stock details updated successfully";
	}
	
	//deleting the stock
	public String deleteStock(int id) throws NoSuchStockException{
		Optional<Stock> opt=stockRepository.findById(id);
		if(opt.isPresent())
		 {
			Stock stock=opt.get();
			stockRepository.delete(stock);
		 } 
		else {
			throw new NoSuchStockException("Stock with " + id + " does not exist");
		}
		return "Stock details deleted successfully";
	}
	
	public int calculateOrder(Stock bean)
	{
		amount=price*quantity;
		return quantity;
		
	}
}

