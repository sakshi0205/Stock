package com.stock.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.stock.entity.Stock;
import com.stock.exception.NoSuchStockException;
import com.stock.exception.StockNotFoundException;
import com.stock.service.StockServiceImpl;




@RestController
public class StockController {
	@Autowired
	StockServiceImpl service;
	
	//to create stock
	@PostMapping(value="/stocks")
	public ResponseEntity<String> createStocks(@RequestBody Stock stock) {
		
		
		String response = service.createStock(stock);
		//return new ResponseEntity<String>(response, HttpStatus.OK);
		return ResponseEntity.ok(response);
	}
	
	//use to fetch the stock 
	@GetMapping(value="/stocks")
	public ResponseEntity<List<Stock>>viewallStocks() throws StockNotFoundException{ 
		List<Stock> stock= service.viewallStock();
		return ResponseEntity.ok(stock);
	}
	
	//use to fetch the stock according to id
	@GetMapping(value="/stocks/{id}")
	public ResponseEntity<Stock> findsingleStocks(@PathVariable("id") int id) throws NoSuchStockException{ 
		Stock stock= service.findsingleStocks(id);
		return ResponseEntity.ok(stock);
	}
	
	//use to delete stock as per stock id
	@DeleteMapping(value = "/stocks/{id}")
	public String deleteStocks(@PathVariable("id") int id) throws NoSuchStockException {
		return service.deleteStock(id);
	}
	
	//use to update stock acording to id
	
	@PutMapping(value = "/stocks/{id}")
	public String updateStocks(@PathVariable("id") int id, @RequestBody Stock stock) throws NoSuchStockException{
		return service.updateStock(id, stock);
	}
	
}
