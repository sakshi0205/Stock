package com.stock.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stock.entity.Stock;
import com.stock.exception.NoSuchStockException;
import com.stock.exception.StockNotFoundException;

public interface Stockservice  extends JpaRepository<Stock, Integer>{

	public String createStock(Stock stock);
	public Stock findsingleStocks(int id) throws NoSuchStockException;
	public List<Stock> viewallStock() throws StockNotFoundException;
	public String updateStock(int id,Stock stock) throws NoSuchStockException;
	public String deleteStock(int id) throws NoSuchStockException;
	public int calculateOrder(Stock bean,int amount);
}
