package com.stock.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stock.entity.Stock;



@Repository
public interface StockRepo extends JpaRepository<Stock, Integer> {

	int saveOrder(Stock bean);
	
}
